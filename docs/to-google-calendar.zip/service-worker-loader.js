import './assets/service-worker.ts-BcrnrvNc.js';
